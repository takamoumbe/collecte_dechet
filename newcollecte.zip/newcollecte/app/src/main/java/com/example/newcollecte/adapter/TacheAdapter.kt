package com.example.newcollecte.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.newcollecte.R
import com.example.newcollecte.model.TacheModel

internal class TacheAdapter(private var itemsList: List<TacheModel>):
    RecyclerView.Adapter<TacheAdapter.MyViewHolder>(){

    internal inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view){
        var nbre_dechet: TextView       = view.findViewById(R.id.nbre_dechet)
        var date_creation: TextView     = view.findViewById(R.id.date_creation)
        var status: TextView            = view.findViewById(R.id.status)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TacheAdapter.MyViewHolder {
        val intemView = LayoutInflater.from(parent.context).inflate(R.layout.ligne_tache, parent, false)
        return  MyViewHolder(intemView)
    }

    override fun onBindViewHolder(holder: TacheAdapter.MyViewHolder, position: Int) {
        val item = itemsList[position]
        val nbre_dechet = item?.nbre_dechet
        val date_creation = item?.created_at
        val status = item?.status_tache
        holder.nbre_dechet.text = ""+nbre_dechet
        holder.date_creation.text = date_creation
        holder.status.text = ""+status
    }

    override fun getItemCount(): Int {
        return  itemsList.size
    }

}