package com.example.newcollecte.model

// un utilisateur connecte
data class UserModel(var success: Boolean, var status: Int, var msg: String, var token: String, var type_user:String, var id_user: Int, var nom:String, var prenom:String, var login:String)

// objet terminer la tache
data class NotifcationModel(var success: Boolean, var  status: Int, var msg: String)

// message retour d'insertion de la base donnée
data class ResponseSaveDechet(var success: Boolean, var  status: Int, var msg: String)

// liste des agences
data class ListAgence(var id_agence: Int, var nom_agence: String, var email_agence: String, var lieu_agence: String, var status_agence: Int)

// liste tache
data class TacheModel(val nbre_dechet: Int, val date: String, val etat: Int, val status_tache: Int, val created_at: String, val updated_at: String, val deleted_at:String)














