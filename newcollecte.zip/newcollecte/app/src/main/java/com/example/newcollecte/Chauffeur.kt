package com.example.newcollecte

import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.newcollecte.`interface`.TACHE
import com.example.newcollecte.adapter.TacheAdapter
import com.example.newcollecte.internet.Internet
import com.example.newcollecte.model.TacheModel
import retrofit2.Call
import retrofit2.Response

class Chauffeur : AppCompatActivity() {
    private val itemsList = ArrayList<TacheModel>()
    private lateinit var tacheAdapter: TacheAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chauffeur)

        val internet = Internet()
        if (!internet.checkForInternet(applicationContext)){
            Toast.makeText(this, "⚠⚠Erreur de Connexion Internet", Toast.LENGTH_SHORT).show()
        }else{
            var dialog: ProgressDialog? = null
            dialog = ProgressDialog(this)
            dialog.setMessage("Chargement...")
            dialog.setCanceledOnTouchOutside(false)
            dialog.show()

            try{
                TACHE.retrofitetache.getTache().enqueue(object : retrofit2.Callback<List<TacheModel>>{
                    override fun onResponse(call: Call<List<TacheModel>>, response: Response<List<TacheModel>>) {
                        if (response.isSuccessful){

                            val resultat = response.body()
                            val recyclerView: RecyclerView = findViewById(R.id.recycle_view)
                            tacheAdapter = TacheAdapter(itemsList)
                            val layoutManager = LinearLayoutManager(applicationContext)
                            recyclerView.layoutManager = layoutManager
                            recyclerView.adapter = tacheAdapter
                            prepareItems(resultat)
                            dialog.dismiss()
                        }
                    }

                    override fun onFailure(call: Call<List<TacheModel>>, t: Throwable) {
                        t.printStackTrace()
                        dialog.dismiss()
                        Toast.makeText(applicationContext,"echec de la requete ",Toast.LENGTH_SHORT).show()
                    }
                })
            }catch (e:Exception){
                Toast.makeText(this,"Vérifier votre connection Internet ",Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun prepareItems(data: List<TacheModel>?) {
        val taille = data?.size

        for (i in 0..100){
            val numObject = data?.get(i)
            if (numObject != null) {
                itemsList.add(numObject)
            }
        }
        tacheAdapter.notifyDataSetChanged()
    }
}