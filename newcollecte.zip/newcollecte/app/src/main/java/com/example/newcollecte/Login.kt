package com.example.newcollecte

import android.annotation.SuppressLint
import android.app.Application
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.annotation.RequiresApi
import com.example.newcollecte.`interface`.CONFIGURATION
import com.example.newcollecte.internet.Internet
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class Login : AppCompatActivity() {
    // declaration de la variable sharePreference
    lateinit var sharedPreferences: SharedPreferences

    private lateinit var login: EditText
    private lateinit var pass: EditText
    private lateinit var connexion: Button
    private lateinit var spinner: ProgressBar
    private lateinit var error: TextView
    private lateinit var identification: TextInputLayout
    // declaration des cles de la session
    var PREFS_KEY       = "prefs"
    var SUCCESS_KEY     = "success"
    var STATUS_KEY      = "status"
    var MSG_KEY         = "msg"
    var TOKEN_KEY       = "token"
    var ID_KEY          = "id_user"
    var NOM_KEY         = "nom"
    var PRENOM_KEY      = "prenom"
    var TYPE_USER_KEY   = "type_user"
    var LOGIN_KEY       = "login_k"

    // initialisation des variables
    var success         = ""
    var status          = ""
    var msg             = ""
    var token           = ""
    var id_user         = ""
    var nom             = ""
    var type_user       = ""
    var prenom          = ""
    var login_k         = ""

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // validator
        connexion       = findViewById(R.id.connexion)
        login           = findViewById(R.id.login)
        pass            = findViewById(R.id.pass)
        error           = findViewById(R.id.error)
        spinner         = findViewById(R.id.progressBar)
        spinner.setVisibility(View.GONE)

        val internet = Internet()
        if (!internet.checkForInternet(applicationContext)){
            error.text= "⚠⚠Erreur de Connexion Internet"
            error.setTextColor(Color.RED)
        }else{
            connexion.setOnClickListener(object : View.OnClickListener {
                @SuppressLint("SuspiciousIndentation")
                @RequiresApi(Build.VERSION_CODES.S)
                override fun onClick(p0: View?) {
                    val login = login.getText().toString().trim()
                    val pass  = pass.getText().toString().trim()
                    spinner.setVisibility(View.VISIBLE)
                    connexion.isClickable = true
                    error.text = ""

                    // validation de l'identification
                    if (login == "" || pass == ""){
                        error.text = "⚠⚠Champs invalides"
                        error.setTextColor(Color.RED)
                    }else{
                        // fabriquez un jsonObject
                        val jsonObject = JSONObject()
                        jsonObject.put("login", login)
                        jsonObject.put("passwordk", pass)
                        val jsonObjectString = jsonObject.toString()
                        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())

                        CoroutineScope(Dispatchers.IO).launch {
                            // Do the POST request and get response
                            try{
                                val response = CONFIGURATION.retrofite_configurer.authentification(requestBody)
                                if (response.body()?.success == true) {
                                    println(response.body()!!)

                                    // stockage  des parametre dans la sesions
                                    /*------------ INITIALISER LA SESSION ---------*/
                                    sharedPreferences = getSharedPreferences(PREFS_KEY, MODE_PRIVATE)
                                    /*------------ PREPARATION DES VARIABLES ---------*/
                                    success  = sharedPreferences.getString(SUCCESS_KEY, "").toString()
                                    status   = sharedPreferences.getString(STATUS_KEY, "").toString()
                                    msg      = sharedPreferences.getString(MSG_KEY, "").toString()
                                    token    = sharedPreferences.getString(TOKEN_KEY, "").toString()
                                    id_user  = sharedPreferences.getString(ID_KEY, "").toString()
                                    nom      = sharedPreferences.getString(NOM_KEY, "").toString()
                                    type_user= sharedPreferences.getString(TYPE_USER_KEY, "").toString()
                                    prenom = sharedPreferences.getString(PRENOM_KEY, "").toString()
                                    login_k= sharedPreferences.getString(LOGIN_KEY, "").toString()


                                    /*------------ EDITION DE LA SESSION ---------*/
                                    val editor: SharedPreferences.Editor = sharedPreferences.edit()
                                    editor.putString(SUCCESS_KEY, response.body()!!.success.toString())
                                    editor.putString(STATUS_KEY, response.body()!!.status.toString())
                                    editor.putString(MSG_KEY, response.body()!!.msg)
                                    editor.putString(ID_KEY, response.body()!!.id_user.toString())
                                    editor.putString(NOM_KEY, response.body()!!.nom)
                                    editor.putString(PRENOM_KEY, response.body()!!.prenom)
                                    editor.putString(TYPE_USER_KEY, response.body()!!.type_user)
                                    editor.putString(LOGIN_KEY, response.body()!!.login)
                                    editor.putString(TOKEN_KEY, response.body()!!.token)
                                    editor.apply()

                                    connexion.isClickable = true

                                   // Toast.makeText(applicationContext,"Bienvenue",Toast.LENGTH_SHORT).show()
                                    if(response.body()?.type_user == "collecteur"){
                                        val i = Intent(applicationContext, Chauffeur::class.java)
                                        startActivity(i)
                                        finish()
                                    }else if(response.body()?.type_user == "entrepot"){
                                        /*val i = Intent(applicationContext, Ch::class.java)
                                        startActivity(i)
                                        finish()*/
                                    }

                                }else{
                                    println(response.body()!!)
                                    error.text = "⚠⚠"+response.body()?.msg;
                                    connexion.isClickable = true
                                }
                            }catch (e:Exception){
                                error.text = "⚠⚠Erreur de Connexion Internet";
                                connexion.isClickable = true

                                e.printStackTrace();
                            }
                        }
                    }
                }
            });
        }
    }
}