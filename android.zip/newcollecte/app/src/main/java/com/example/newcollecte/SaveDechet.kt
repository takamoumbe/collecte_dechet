package com.example.newcollecte

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.example.newcollecte.`interface`.SENDDECHET
import com.example.newcollecte.internet.Internet
import com.github.dhaval2404.imagepicker.ImagePicker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File

class SaveDechet : Activity(), AdapterView.OnItemSelectedListener {

    val REQUEST_IMAGE_CAPTURE = 1
    private  val requestGallery = 2121
    lateinit var imageView:ImageView
    lateinit var buttonTakePhoto: ImageButton
    lateinit var buttonLogin: ImageButton
    lateinit var description: EditText
    lateinit var telephone: EditText
    lateinit var message: TextView
    lateinit var enregistrer: Button
    var select: String = ""
    var url_img: String = ""

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_save_dechet)

        description     = findViewById(R.id.description)
        enregistrer     = findViewById(R.id.enregistrer)
        message         = findViewById(R.id.message)
        telephone       = findViewById(R.id.telephone)
        imageView       = findViewById(R.id.imageView2)
        buttonLogin     = findViewById(R.id.flotting_login)
        buttonTakePhoto = findViewById(R.id.floatingActionButton2)
        buttonTakePhoto.setImageResource(R.drawable.ic_baseline_camera_alt_24)
        buttonLogin!!.setOnClickListener{
            val i = Intent(this, Login::class.java)
            startActivity(i)
            finish()
        }

        val internet = Internet()
        buttonTakePhoto.setOnClickListener {

            if (!internet.checkForInternet(applicationContext)){
                message.text="⚠️⚠ Pas de Connexion Internet"
                message.setTextColor(Color.RED)
            }else{
                if (validationForm()){
                    ImagePicker.with(this).start(requestGallery)
                }
            }
        }

        enregistrer.setOnClickListener {
            if (!internet.checkForInternet(applicationContext)){
                message.text="⚠️⚠ Pas de Connexion Internet"
                message.setTextColor(Color.RED)
            }else{
                validationForm()
            }
        }



        val spinner: Spinner = findViewById(R.id.planets_spinner)
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter.createFromResource(
            this,
            R.array.planets_array,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            // Apply the adapter to the spinner
            spinner.adapter = adapter
        }

        spinner.onItemSelectedListener = this

    }

    override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
        // An item was selected. You can retrieve the selected item using
        //Toast.makeText(this, ""+parent.getItemAtPosition(pos), Toast.LENGTH_SHORT).show()
        this.select = parent.getItemAtPosition(pos) as String
    }

    override fun onNothingSelected(parent: AdapterView<*>) {
        // Another interface callback
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == requestGallery && data != null) {
                val fileUri = data.data
                setImage(fileUri!!)
                ImagePicker.getFile(data)?.let { doRequest(it,fileUri) } ?: run{ Toast.makeText(applicationContext,"Ops. Something went wrong.",Toast.LENGTH_SHORT)}

            }
        }

    }

    private fun setImage(uri: Uri) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(contentResolver, uri)
            val bitmap = ImageDecoder.decodeBitmap(source)
            imageView.setImageBitmap(bitmap)
        } else {
            @Suppress("DEPRECATION") val bitmap =
                MediaStore.Images.Media.getBitmap(contentResolver, uri)
            imageView.setImageBitmap(bitmap)
        }
    }

    private fun doRequest(file: File, uri: Uri){
        message.setTextColor(Color.GREEN)
        message.text = "Veuiller Patienter !!!";

        if (validationForm()){
            val requestFile = file.asRequestBody(contentResolver.getType(uri)?.toMediaTypeOrNull())

            // preparation des donnees
            val multipartBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("type_dechet", this.select)
                .addFormDataPart("description", description.text.toString())
                .addFormDataPart("contact", telephone.text.toString())
                .addFormDataPart("image", file.name, requestFile)
                .build()

            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val response = SENDDECHET.retrofit_sendDechet.sendDechet(multipartBody)

                    withContext(Dispatchers.Main){
                        if (response.isSuccessful){
                            if (response.body()?.success == true){
                                println(response.body()!!)
                                message.text = ""+response.body()?.msg;
                                message.setTextColor(Color.GREEN)
                                enregistrer.isClickable = true
                            }else{
                                message.text = ""+response.body()?.msg;
                                enregistrer.isClickable = true
                            }
                        }else{
                            message.text = "⚠️⚠Oousp Une Erreur est Survenue";
                            message.setTextColor(Color.RED)
                            enregistrer.isClickable = true
                        }
                    }
                }catch(e:Exception){

                    message.text = "⚠️⚠Erreur de Connexion Internet";
                    message.setTextColor(Color.RED)
                    enregistrer.isClickable = true

                    e.printStackTrace();

                }
            }
        }
    }

    private fun validationForm(): Boolean{
        // validation des champs du formulaire
        if (select == "" || select == "Type de Déchets" || telephone.text.toString() == "" || description.text.toString() == "" ){

            message.text = "⚠️⚠Joindre la photo a la fin"
            message.setTextColor(Color.RED)
            return false
        }else if(telephone.text.toString().length != 9){
            message.text = "⚠️⚠ Contact Incorrect"
            message.setTextColor(Color.RED)
            return false
        }else if (select == "" || select == "Type de Déchets"){
            message.text = "⚠️⚠ Type de dechet Obligatoire"
            message.setTextColor(Color.RED)
            return false
        }

        return true
    }

}


