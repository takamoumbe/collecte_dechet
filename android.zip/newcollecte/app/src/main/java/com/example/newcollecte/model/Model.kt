package com.example.newcollecte.model

// un utilisateur connecte
data class UserModel(var success: Boolean, var status: Int, var msg: String, var token: String, var type_user:String)

// objet marquer une presence
data class NotifcationModel(var success: Boolean, var  status: Int, var msg: String)

// message retour d'insertion de la base donnée
data class ResponseSaveDechet(var success: Boolean, var  status: Int, var msg: String)